import React ,{Component} from 'react';
class Clients extends React.Component{
  constructor(props){
    super(props);
    this.state={
        users: [],
    };
    }
    componentDidMount() {
        fetch("https://jsonplaceholder.typicode.com/users")
          .then((response) => response.json())
          .then((data) => {
            this.setState({ ...this.state, users: data });
            console.log(this.state.users);
          });
      }
      render(){
        let user_details = this.state.users.map((item, index) => {
            return (
                  <tr>
                    <th scope="row">{item.id}</th>
                    <td>{item.name}</td>
                    <td>{item.email}</td>
                    <td>{item.website}</td>
                  </tr>
            );
            });
          return (
            <>
             <table class="table table-dark">
                <thead>
                  <tr>
                    <th scope="col">SLno</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Website</th>
                  </tr>
                </thead>
                <tbody>
                  {user_details}
                  </tbody>
              </table>
            </>
          );
        }
      }
      
export default Clients;