import React ,{Component} from 'react';
class Blog extends React.Component{
  constructor(props){
    super(props);
    this.state={
        Blog:[
            {
             name:"Redmi 9 Power (Mighty Black 4GB RAM 64GB Storage)",
             price:"10200",
             description:`Android v10.0 operating system with 1.7GHz+2.3GHz Exynos 9611 Octa core processor
             Memory, Storage & SIM: 6GB RAM | 128GB internal memory expandable up to 512GB 6000mAH lithium-ion battery with 3x fast charge`,
             image:"../../Images/redmi.jpg",
            },
            {
                name:"Samsung Galaxy M31 (Iceberg Blue, 6GB RAM, 128GB Storage)",
                price:"14500",
                description:`16.58 centimeters (6.53 inch) FHD+ multi-touch capacitive touchscreen with 2340 x 1080 pixels resolution,
                Memory, Storage & SIM: 4GB RAM | 64GB internal memory expandable up to 512GB
                Android v10 operating system with upto 2.0GHz clock speed Qualcomm Snapdragon 662 octa core processor`,
                image:"../../Images/sumsung.jpg"
            },
            {
                name:"Redmi 9 Power (Mighty Black 4GB RAM 64GB Storage)",
                price:"10200",
                description:`Android v10.0 operating system with 1.7GHz+2.3GHz Exynos 9611 Octa core processor
                Memory, Storage & SIM: 6GB RAM | 128GB internal memory expandable up to 512GB 6000mAH lithium-ion battery with 3x fast charge`,
                image:"../../Images/redmi.jpg"
            },
            {
                name:"Samsung Galaxy M31 (Iceberg Blue, 6GB RAM, 128GB Storage)",
                price:"14500",
                description:`16.58 centimeters (6.53 inch) FHD+ multi-touch capacitive touchscreen with 2340 x 1080 pixels resolution,
                Memory, Storage & SIM: 4GB RAM | 64GB internal memory expandable up to 512GB Android v10 operating system with upto 2.0GHz clock speed Qualcomm Snapdragon 662 octa core processor`,
                image:"../../Images/sumsung.jpg"
            },
        ],
    };
    }

    render(){
        let phone_Blogs = this.state.Blog.map((item, index) => {
            return (
              <div className="col-md-4 mb-2" key={index}>
                <div className="card">
                  <div className="card-body">
                    <h4 className="card-title">{item.name}</h4>
                    <h6 className="card-subtitle mb-2 text-secondary">Price: ₹{item.price}</h6>
                    <p className="card-text text-justify">{item.description}</p>
                    <img className="card-image pl-5" width="200px" height="150px" src={item.image}/>
                    <p><a href="#" className="card-link text-primary pl-5">
                      Purchase Now 
                    </a></p>
                  </div>
                </div>
              </div>
            );
            });
          return (
            <>
             <h1>Blogs</h1>
              <section className="container">
                <div className="row">
                  {phone_Blogs}
                </div>
              </section>
            </>
          );
        }
      }
      
export default Blog;