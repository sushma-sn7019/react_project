import logo from '../../Images/AIT.jpg';
import '../../App.css';
import {Link} from 'react-router-dom';
let Header=()=>{
    return(
        <>
         <nav className="navbar navbar-expand-lg navbar-light bg-light">
      <div className="container-fluid">
        <a className="navbar-brand" href="#">
          <img src={logo} alt="AchieversIT" />
        </a>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav">
            <li className="nav-item">
              <Link to="/" className="nav-item">
                Home
                </Link>
            </li>
            <li className="nav-item pl-3">
            <Link to="/about">
                About
            </Link>
            </li>    
            <li className="nav-item pl-3">
            <Link to="/services">
                Services
             </Link>
            </li>    
            <li className="nav-item pl-3">
            <Link to="/clients">
                Clients
             </Link>
            </li>
            
            <li className="nav-item pl-3">
            <Link to="/blog">
                Blog
              </Link>
            </li>
            
            <li className="nav-item pl-3">
            <Link to="/contact">
                Contact
            </Link>
            </li>
          </ul>
        </div>
      </div>
    </nav>
        </>
    )
}
export default Header;