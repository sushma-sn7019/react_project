
import React ,{Component} from 'react';
import Slider from '../Slider';
import '../../home.css'
class Home extends React.Component{
  constructor(props){
    super(props);
    this.state={
        products: [
            {
              name:"Angular Development Training",
              ico:<i className="fab fa-angular fa-space fa-4x"></i>,
              desc:'Angular is popular for making dynamic applications and its information official and reliance infusion includes altogether lessen the measure of code that should be composed.',
              star:'5',
              ratings:'292',
              course:'Angular',
            },
            {
              name:"React Development Training",
              ico:<i className="fab fa-react fa-space fa-4x"></i>,
              desc:'Achievers IT React JS Certification Course in Bangalore. We teach you detailed explanations of JSX, Unidirectional data flow and Flux, Components etc.',
              star:'5',
              ratings:'200',
              course:'React',
            },
            {
              name:"MEAN Development training",
              ico:<i className="fas fa-shield-alt  fa-space fa-4x"></i>,
              desc:'MEAN Stack Front To Back". In this course we will build an in depth full stack social network application using Angular, Express, React, Redux and MongoDB along with ES6+.',
              star:'4.9',
              ratings:'250',
              course:'MEAN',
            },
            {
              name:"Web Development training",
              ico:<i className="fas fa-globe fa-space fa-4x"></i>,
              desc:'With AchieversIT’s UI development course in bangalore, you will be able to master the concepts such as CSS3, CSS, HTML, JavaScript, Bootstrap, HTML5, JQuery, Angular/ReactJS etc.',
              star:'5',
              ratings:'180',
              course:'Web Development',
            },
            {
              name:"Digital Marketing Training",
              ico:<i className="fas fa-chart-bar  fa-space fa-4x"></i>,
              desc:'Achievers IT React JS Certification Course in Bangalore. We teach you detailed explanations of JSX, Unidirectional data flow and Flux, Components etc.',
              star:'4.5',
              ratings:'158',
              course:'Digital Marketing',
            },
            {
              name:"UI Development training",
              ico:<i className="fab fa-uikit  fa-space fa-4x"></i>,
              desc:'MEAN Stack Front To Back". In this course we will build an in depth full stack social network application using Angular, Express, React, Redux and MongoDB along with ES6+.',
              star:'4.8',
              ratings:'132',
              course:'UI',
            },
            ],

    }
};
    render(){
            let courses = this.state.products.map((item,index)=>{
              return(
                  <>                
                <div className="col-md-3 ml-0 mt-3 p-0" >
                <div className="ml-5 b-shadow">
                    <div className="bg-a" key={index}>
                        <span className="d-flex mr-5 text-white">
                            {item.ico}
                            <h4 className="col-md-1">{item.name}</h4>
                        </span>
                    </div>
                    <div className="card-body p-1">
                        <h5 className="card-title text-danger">{item.course}</h5>
                        <p className="card-text">{item.desc}</p>
                        <div class="card-footer bg-white">
                            <div class="course-trend-reviews  text-black">
                            <h6><i>Reviews</i></h6>
                            <span class="review-icons text-yellow"> <i class="fas fa-star"></i> <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i> </span><span><b>{item.star}</b>
                            </span><span><b> ({item.ratings})</b></span>
                            </div>
                        </div>
                        <a href="#" className="mlb-80 btn btn-primary">Join Course</a>       
                    </div>
                </div>
                </div>
              </>
              )
            });
    return(
    <>
        <div className=" col-md-12 bgimg-home">
        <div className="container-fluid">
            <div className="col-md-5">
                <h2 className="text-white">Welcome To Acheiver's IT</h2>
                <h4 className="text-white">Best Online Eduction Expertise</h4>
                <p className="text-white">AchieversIT - provides a wide group of opportunities for freshers and Experienced candidate who can develop their skills and build their career opportunities across multiple Companies.</p>
            </div>
        </div>
        </div>
        <Slider/>
        <div className="container-fluid">
        <div className="col-md-12 d-flex">
            <div className="row">
                {courses}
            </div>
        </div>
        </div>
  </>
    );  
}
};
export default Home;