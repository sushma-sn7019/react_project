let Contact=()=>
{
    return<p>Contact page design</p>
}
export default Contact;