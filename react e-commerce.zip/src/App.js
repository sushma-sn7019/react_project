import './App.css';
import { BrowserRouter as Router,Switch,Route} from 'react-router-dom';
import Header from './Component/Header';
import Home from './Component/Home';
import About from './Component/About';
import Services from './Container/Services';
import Clients from './Container/Clients';
import Blog from './Container/Blog';
import Contact from './Component/Contact';
import Footer from './Component/Footer';

function App() {
  return (
    <>
   <Router>
   <Header/>
   
   <Switch>
   <Route path="/" component={Home} exact></Route>
   </Switch>
   <Switch>
   <Route path="/about" component={About} exact></Route>
   <Route path="/services" component={Services}exact></Route>
   <Route path="/clients" component={Clients} exact></Route>
   <Route path="/blog" component={Blog} exact></Route>
   <Route path="/contact" component={Contact} exact></Route>
   </Switch>
   <Footer/>
   </Router>
   </>
  );
}

export default App;
